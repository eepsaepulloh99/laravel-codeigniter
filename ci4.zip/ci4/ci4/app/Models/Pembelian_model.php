<?php

namespace App\Models;

use CodeIgniter\Model;

class Pembelian_model extends Model
{
    protected $table = 'suppliers';

    public function getBuy()
    {
        $builder = $this->db->table('buys');
        $builder->select('*');
        return $builder->get();
    }
    public function saveBuy($data)
    {
        $query = $this->db->table('buys')->insert($data);
        return $query;
    }
    public function saveDetailBuy($data)
    {
        $query = $this->db->table('buy_details')->insert($data);
        return $query;
    }
    public function laporanBuy($awal, $akhir)
    {
        $builder = $this->db->table('buys'); // menentukan tabel
        $builder->select('*'); // menentukan colom
        $builder->where('tgl_buy >=', $awal);
        $builder->where('tgl_buy <=', $akhir);
        $query = $builder->get(); // untuk eksekusi
        return $query;
    }
}
