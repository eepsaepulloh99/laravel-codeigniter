<?php

namespace App\Models;

use CodeIgniter\Model;

class Supplier_model extends Model
{

    public function getSupplier()
    {
        $builder = $this->db->table('suppliers');
        $builder->select('*');
        return $builder->get();
    }

    public function saveSupplier($data)
    {
        $query = $this->db->table('suppliers')->insert($data);
        return $query;
    }

    public function editSupplier($id)
    {
        $builder = $this->db->table('suppliers'); // menentukan tabel
        $builder->select('*'); // menentukan colom
        $builder->where('id_supplier', $id);  //where ini sebagai conditional
        $query = $builder->get(); // untuk eksekusi
        return $query;
    }

    public function updateSupplier($data, $id)
    {
        $query = $this->db->table('suppliers')->update($data, array('id_supplier' => $id));
        return $query;
    }

    public function deleteSupplier($id)
    {
        $query = $this->db->table('suppliers')->delete(array('id_supplier' => $id));
        return $query;
    }
}
