<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Supplier_model;

class Supplier extends BaseController
{
    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $model = new Supplier_model();
            $data['supplier']  = $model->getSupplier()->getResult();

            echo template('Pembelian/view_supplier', $data);
        } else {

            return redirect()->to('/auth');
        }
    }

    public function getSupplier()
    {
        $model = new Supplier_model();
        $data  = $model->getSupplier()->getResult();

        echo json_encode($data);
    }

    public function save()
    {
        $model = new Supplier_model();
        $data = array(
            'name_supplier'        => $this->request->getPost('namasupplier'),
            'address_supplier'       => $this->request->getPost('addresssupplier'),
            'telp_supplier' => $this->request->getPost('telpsupplier')
        );
        $data = $model->saveSupplier($data);
        echo json_encode($data);
    }

    public function editSupplier()
    {
        $model = new Supplier_model();
        $id = $this->request->getPost('idsupplier'); // dikirim dari :data{idproduct:idproduct} ajax
        $data = $model->editSupplier($id)->getResult();
        echo json_encode($data);
    }

    public function updateSupplier()
    {
        $model = new Supplier_model();
        $id = $this->request->getPost('idsupplier');
        $data = array(
            'name_supplier'        => $this->request->getPost('namasupplier'),
            'address_supplier'       => $this->request->getPost('addresssupplier'),
            'telp_supplier' => $this->request->getPost('telpsupplier')
        );
        $data = $model->updateSupplier($data, $id);
        echo json_encode($data);
    }

    public function delete()
    {
        $model = new Supplier_model();
        $id = $this->request->getPost('idsupplier'); // dikirim dari :data{idproduct:idproduct} ajax
        $data = $model->deleteSupplier($id);
        echo json_encode($data);
    }
}
