<?php

namespace App\Controllers;

class ReturProduct extends BaseController
{
    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $data['menu'] = '';
            echo template('transaksi', $data);
        } else {

            return redirect()->to('/auth');
        }
    }
}
